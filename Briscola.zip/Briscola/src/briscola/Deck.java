/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package briscola;

/**
 *
 * @author l.agnani
 */
public class Deck
{
    private Card[] carte= new Card[40];
    
    public void create()
    {
        for(int k=0; k<40; k++)
        {
            for(int j=0; j<4; j++)
            {
                for(int i=0; i<10; i++)
                {
                    carte[k]=new Card(null, null, null, i+1, j+1, 0);
                    switch(carte[k].getSuit())
                    {
                        case 1:
                            carte[k].setSuitname("Bastoni");
                            break;
                        case 2:
                            carte[k].setSuitname("Coppe");
                            break;
                        case 3:
                            carte[k].setSuitname("Denari");
                            break;
                        case 4:
                            carte[k].setSuitname("Spade");
                            break;
                    }
                    switch(carte[k].getNumber())
                    {
                        case 1:
                            carte[k].setCardname("Asso");
                            carte[k].setValue(11);
                            break;
                        case 2:
                            carte[k].setCardname("Due");
                            carte[k].setValue(0);
                            break;
                        case 3:
                            carte[k].setCardname("Tre");
                            carte[k].setValue(10);
                            break;
                        case 4:
                            carte[k].setCardname("Quattro");
                            carte[k].setValue(0);
                            break;
                        case 5:
                            carte[k].setCardname("Cinque");
                            carte[k].setValue(0);
                            break;
                        case 6:
                            carte[k].setCardname("Sei");
                            carte[k].setValue(0);
                            break;
                        case 7:
                            carte[k].setCardname("Sette");
                            carte[k].setValue(0);
                            break;
                        case 8:
                            carte[k].setCardname("Fante");
                            carte[k].setValue(2);
                            break;
                        case 9:
                            carte[k].setCardname("Cavallo");
                            carte[k].setValue(3);
                            break;
                        case 10:
                            carte[k].setCardname("Re");
                            carte[k].setValue(4);
                            break;
                    }
                    
                    carte[k].setName(carte[k].getCardname()+ " di "+ carte[k].getSuitname());
                }
            }
        }
    }
    
    public void Print()
    {
        for(int i=0; i<40; i++)
        {
            System.out.println(carte[i].getName());
        }
    }
}
