/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package briscola;

/**
 *
 * @author l.agnani
 */
public class Card 
{
    private String name;
    private String suitname;
    private String cardname;
    private int number;
    private int suit;
    private int value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSuitname() {
        return suitname;
    }

    public void setSuitname(String suitname) {
        this.suitname = suitname;
    }

    public String getCardname() {
        return cardname;
    }

    public void setCardname(String cardname) {
        this.cardname = cardname;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getSuit() {
        return suit;
    }

    public void setSuit(int suit) {
        this.suit = suit;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public Card(String name, String suitname, String cardname, int number, int suit, int value) {
        this.name = name;
        this.suitname = suitname;
        this.cardname = cardname;
        this.number = number;
        this.suit = suit;
        this.value = value;
    }

    
    
 
}
