/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package briscola;

import java.util.ArrayList;

/**
 *
 * @author l.agnani
 */
public class Processor
{
    public ArrayList<Card> current;
    private int score;

    public ArrayList<Card> getCurrent() 
    {
        return current;
    }

    public void setCurrent(ArrayList<Card> current) 
    {
        this.current = current;
    }
    
    public int getScore() 
    {
        return score;
    }

    public void setScore(int score) 
    {
        this.score = score;
    }

    public Processor(int score)
    {
        this.score = score;
    }
    
}
