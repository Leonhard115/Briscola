/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package briscola;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author l.agnani
 */
public class Deck
{
    private Card[] carte= new Card[40];
    
    public void create()
    {
        int k=0;
            for(int j=1; j<5; j++)
            {
                for(int i=1; i<11; i++)
                {
                    carte[k]=new Card(null, null, null, i, j, 0);
                    switch(carte[k].getSuit())
                    {
                        case 1:
                            carte[k].setSuitname("Bastoni");
                            break;
                        case 2:
                            carte[k].setSuitname("Coppe");
                            break;
                        case 3:
                            carte[k].setSuitname("Denari");
                            break;
                        case 4:
                            carte[k].setSuitname("Spade");
                            break;
                    }
                    switch(carte[k].getNumber())
                    {
                        case 1:
                            carte[k].setCardname("Asso");
                            carte[k].setValue(11);
                            break;
                        case 2:
                            carte[k].setCardname("Due");
                            carte[k].setValue(0);
                            break;
                        case 3:
                            carte[k].setCardname("Tre");
                            carte[k].setValue(10);
                            break;
                        case 4:
                            carte[k].setCardname("Quattro");
                            carte[k].setValue(0);
                            break;
                        case 5:
                            carte[k].setCardname("Cinque");
                            carte[k].setValue(0);
                            break;
                        case 6:
                            carte[k].setCardname("Sei");
                            carte[k].setValue(0);
                            break;
                        case 7:
                            carte[k].setCardname("Sette");
                            carte[k].setValue(0);
                            break;
                        case 8:
                            carte[k].setCardname("Fante");
                            carte[k].setValue(2);
                            break;
                        case 9:
                            carte[k].setCardname("Cavallo");
                            carte[k].setValue(3);
                            break;
                        case 10:
                            carte[k].setCardname("Re");
                            carte[k].setValue(4);
                            break;
                    }
                    
                    carte[k].setName(carte[k].getCardname()+ " di "+ carte[k].getSuitname());
                    k++;
                }
            }
    }
    
    public void print()
    {
        int p;
        for(int i=0; i<40; i++)
        {
            p=i+1;
            System.out.println(p+ ")"+ carte[i].getName());
        }
    }
    
    public void shuffle()
    {
	Random rand = new Random();
	for (int i=0; i<carte.length; i++)
            {
		int randomPosition = rand.nextInt(carte.length);
		Card temp = carte[i];
		carte[i] = carte[randomPosition];
		carte[randomPosition] = temp;
            }
    }
    
    public int starting(Player p, Processor c, int l)
    {
        int i=0;
        for(i=0; i<3; i++)
        {
            p.hand.add(carte[l]);
            carte[l]=null;
            l++;
            c.current.add(carte[l]);
            carte[l]=null;
            l++;
        }
        return l;
    }
}
