/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package briscola;

import java.util.ArrayList;

/**
 *
 * @author l.agnani
 */
public class Player
{
    public ArrayList<Card> hand;
    private int score;

    public ArrayList<Card> getHand() 
    {
        return hand;
    }

    public void setHand(ArrayList<Card> hand) 
    {
        this.hand = hand;
    }
    
    public int getScore() 
    {
        return score;
    }

    public void setScore(int score) 
    {
        this.score = score;
    }

    public Player(int score)
    {
        this.score = score;
    }
    
}
